//
//  moneyApp.swift
//  money
//
//  Created by Aman Kumar on 23/11/22.
//

import SwiftUI

@main
struct moneyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
